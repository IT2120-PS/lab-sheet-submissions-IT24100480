setwd("//Users//jeeveith//Desktop//IT24100480")
data<-read.table("Data.txt",header = TRUE,sep = ",")
fix(data)
attach(data)
names(data)<-c("x1","x2")
attach(data)
hist(x2,main = "Histogram for number of shrareholders")
##part 2
histogram<-hist(x2,main = "Histogram for number of shareholders",
                breaks = seq(130,270,length=8),right = FALSE)
hist

##part 3
brks<-round(histogram$breaks)
freq<-histogram$counts
mids<-histogram$mids

classes<-c()
for(i in 1:length(brks)-1) {
  classes[i] <- paste0("[",brks[i],",",brks[i+1],")")
}
classes

cbind(Classes=classes,Frequency=freq)

##part4
lines(mids,freq)
plot(mids,freq,type = 'l',main = "Frequency poligan for shareholders",xlab = "Shareholders",ylab = "frequency",ylim = c(0,max(freq)))
##part5
cum.freq<-cumsum(freq)
new<-c()
for (i in 1:length(brks)) {
  if(i==1) {
    new [i]=0
  } else {
    new[i]=cum.freq[i-1]
  }
}
plot(brks,new,type = 'l',main = "Cumilative frequency polygon for shareholders", 
     xlab = "Shareholders", ylab = "Cumilative frequency",ylim = c(0,max(cum.freq)))
cbind(upper=brks,cumfreq=new)
