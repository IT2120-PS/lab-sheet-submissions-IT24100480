 setwd("//Users//jeeveith//Desktop//IT24100480")
branch_data <- read.csv("Exercise.txt",header = TRUE,) 
head(branch_data)
str(branch_data)
boxplot(branch_data$Sales_X1,main = "Boxplot for sale", ylab= "sales")
fivenum(branch_data$Advertising_X2)
IQR(branch_data$Advertising_X2)

find_outliers <= function(x)
{
  
  q1 <- quantile(x,0.25)
  q2 <- quantile(x,0.75)
  IQR_value <- q3-q1
  lower <- q1-1.5$ * IQR_value
  upper <- q3+1.5 * IQR_value
  outliers <- x[x<lower | x>upper]
  return(outliers)
}
find_outliers(branch_data$Years_X3)
